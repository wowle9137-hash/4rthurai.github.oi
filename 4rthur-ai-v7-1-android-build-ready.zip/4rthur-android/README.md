# 4rthur AI Android — Glass Satellite V7.1

This Android project packages the local HTML/CSS/JavaScript interface inside an Android WebView.

## Build configuration
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9 (provisioned by GitHub Actions)
- JDK: 17
- Compile / target SDK: 35
- Minimum Android version: Android 6.0 (API 23)
- Application ID: `com.fourrthur.ai`
- Version: `1.1` (`versionCode` 2)

## Build locally with Android Studio
1. Install JDK 17 and Android SDK Platform 35 plus Build Tools 35.0.0.
2. Open the `4rthur-android/` folder in Android Studio.
3. Wait for Gradle sync to finish.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

Alternatively, from the `4rthur-android/` folder run:

```bash
gradle --no-daemon clean assembleDebug
```

## Build through GitHub Actions
The workflow is stored at repository root in `.github/workflows/build-apk.yml`.
1. Upload/push the complete project so `.github/` and `4rthur-android/` are both at repository root.
2. Open the repository's **Actions** tab.
3. Select **Build and verify 4rthur AI APK**.
4. Choose **Run workflow** and wait for the job to finish successfully.
5. Download the `4rthur-ai-v7.1-debug-apk` artifact from the completed workflow run.

The workflow installs JDK 17, Gradle 8.9, Android SDK 35 and Build Tools 35.0.0, builds the debug APK, verifies its signature, and uploads it as an artifact.

## V7.1 features
- Persistent local chat history (stored on this device only).
- HTML/CSS/JavaScript playground with sandboxed preview.
- Reminder list saved locally, with in-app alerts while the app remains open.
- Dark glass UI, voice input where supported by WebView, and text-to-speech.

## Important limitations
- Chat is a local demo, not connected to an AI model. A secure backend is required for real AI responses. Never embed API secrets in the APK or HTML.
- Reminder alerts currently work only while the app is open. Reliable reminders while closed require native Android alarm/notification integration and Android-version-specific permission handling.
- Automatic prayer schedules and prayer notifications are not included; a trusted location-aware prayer-time provider and native notification implementation are needed.
- The GitHub Actions workflow has been configured but has not been executed in this environment. The APK is therefore not yet built or device-tested.

## Security note
The WebView enables local file access only to load the bundled app asset. Cross-file and universal file-origin access remain disabled, and mixed content is blocked.
